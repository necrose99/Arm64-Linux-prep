emerge sys-apps/file[python] app-text/asciidoc
emerge app-admin/enman app-admin/matter sys-apps/entropy-server app-admin/equo app-misc/sabayon-devkit/
emerge  layman