rm /stage3-arm64-20160324.tar.bz2
## self distruct cleaner 
ln -s proot-start.sh proot-start
rm /Dockerfile
rm /tidyup.sh
